﻿using UnityEngine;
using System.Collections;

public class rpg : MonoBehaviour {

	public class Entidade 
	{
		public int posx;
		public int posy;
	}

	public class Personagem: Entidade
	{
		public int HP;
		public int MP;
		public int Dano;
		public int Andar;
		public string Falar()
		{
			return "Ola";
		}
	}

	public class Jogador: Personagem
	{

	}

	public class NaoJogador
	{
		public void AjudarMagica()
		{

		}

		public void DarItem()
		{

		}
	}

	public class Inimigo
	{
		public void Atacar (int Dano, Personagem alvo)
	}

	public class Mapa:Entidade
	{

	}
	public class Floresta: Entidade
	{

	}

	public class Caverna
	{

	}

	public class Rio 
	{

	}
	public class Acampamento
	{

	}
}
